/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

void `$INSTANCE_NAME`_Test(void);
void `$INSTANCE_NAME`_Start(void);
uint8_t `$INSTANCE_NAME`_Scan(void);

/* [] END OF FILE */
